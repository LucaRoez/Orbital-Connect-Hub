import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
    apiKey: "AIzaSyC8MvZHkeOfhy3dYtDX8rm4f2wI9VJ0cvc",  
    authDomain: "orbital-connect-hub.firebaseapp.com",  
    projectId: "orbital-connect-hub",  
    storageBucket: "orbital-connect-hub.firebasestorage.app",  
    messagingSenderId: "740231673981",  
    appId: "1:740231673981:web:ba9a62b79d1563fd4d1914",  
    measurementId: "G-4G1KKEH12S"
  };
  
  const app = initializeApp(firebaseConfig);
  
  const db = getFirestore(app);
  
  export { db };